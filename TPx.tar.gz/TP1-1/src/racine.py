#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Recherche de racines """


def bissection(f, a, b, good):
    """ Documentation """
    return 0.0
